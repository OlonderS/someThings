﻿using System;
using System.Collections.Generic;
using System.Linq;


    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Runtime.Serialization.Formatters.Binary;
    using System.Text;
    using System.Threading.Tasks;
    using System.Xml.Serialization;

    namespace WpfApp2
    {
        public class CenaComparator : Comparer<Zakup>
        {
            public override int Compare(Zakup x, Zakup y)
            {
            //return x.produkt.Cena.CompareTo(y.produkt.Cena);
            return x.ObliczCene().CompareTo(y.ObliczCene());
            }
        }
        
        public static class Klient
        {
            public static List<Zakup> listaZakupow = new List<Zakup>(); //zakup dwa pola 
            public static float kwota=0;
       
            static void DodajDoListy(Produkt produkt, int liczba = 1) // czy w ogole w gui zrobisz tak zeby dodac wiecej niz 1 item naraz bo tutaj raczej trzeba dać zakup nie produkt i liczba
            {
                listaZakupow.Add(new Zakup(produkt, liczba));
                kwota += produkt.Cena * liczba;
            }

            public static void UsunZListy(Zakup zakup)
            {
                listaZakupow.Remove(zakup);
            }

           public static void ZmienIlosc(Zakup z, int liczba)
            {
            z.ilosc = liczba;
            }

           public static float WartoscZakupow() // chyba wywaliles kwote a imo lepiej dac pole kwota ktore bedzie na biezaco aktualizowane jak cos dodasz do koszyka niz robic przycisk z liczeniem kwoty 
            {
                int suma = 0;
                listaZakupow.ForEach(x => suma += (x.ilosc) * x.produkt.Cena);
                return suma;
            }

        public static void Sortuj() // nie wiem po czym sortuje nawet xD
        {
            listaZakupow.Sort();
        }

        public static void SortujPoCenie()
        {
            listaZakupow.Sort(new CenaComparator());
            //listaZakupow.Sort((x, y) => x.Cena.CompareTo(y.Cena));
        }

        public static string  WyswietlListe()
        {
            StringBuilder sb = new StringBuilder();
            listaZakupow.ForEach(x => sb.Append(x.ToString()));
            return sb.ToString();
        }    


            //static void ZapiszXml(string nazwa) //klasy musza byc public i domyslne konstruktory i pola publiczne/miec metody dostepowe
            //{
            //    XmlSerializer xs = new XmlSerializer(typeof(Klient));
            //    using (StreamWriter sw = new StreamWriter(nazwa))
            //    {
            //        xs.Serialize(sw, this);
            //    }
            //}
            // static Klient OdcztytajXml(string nazwa)
            //{
            //    XmlSerializer serializer = new XmlSerializer(typeof(Klient));
            //    if (!File.Exists(nazwa))
            //        return null;
            //    using (StreamReader sr = new StreamReader(nazwa))
            //    {
            //        return (Klient)serializer.Deserialize(sr);
            //    }
            //}

        }
    }

   




﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
       
        
        public MainWindow()
        {
            InitializeComponent();

            //Producenci producent, string model, int cena, float wysokosc, float szerokosc, float glebokosc, Materialy material, int dostepna_liczba
            Stolik stolikSzwedzki  = new Stolik(Producenci.Alfa , "StolikSzwedzki" , 100 , 50,50,20,Materialy.dąb,Ksztalty.prostokątny);
            Zakup Z = new Zakup(stolikSzwedzki,3);
            Klient.listaZakupow.Add(Z);
            Sklep.ListaProduktow.Add(stolikSzwedzki);
          
        }

        private void Button_ClickPracownik(object sender, RoutedEventArgs e)
        {
            Window1 okno = new Window1();
            okno.Show();
        }

        private void Button_ClickKlient(object sender, RoutedEventArgs e)
        {
            WindowKlient oknoklient = new WindowKlient();
            oknoklient.Show();
        }
    }
}

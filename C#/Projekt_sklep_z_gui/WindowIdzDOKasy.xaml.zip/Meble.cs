﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp2
{
    class Szafa : Produkt
    {
        Kategorie kategoria;
        int liczbaDrzwi;
        bool rozsuwana;
        public int LiczbaDrzwi { get => liczbaDrzwi; set => liczbaDrzwi = value; }
        public bool Rozsuwana { get => rozsuwana; set => rozsuwana = value; }
        public Kategorie Kategoria { get => kategoria; set => kategoria = value; }

        public Szafa()
        {
            Kategoria = Kategorie.Szafa;
        }

        public Szafa(Producenci producent, string model, int cena, float wysokosc, float szerokosc, float glebokosc, Materialy material,  int liczbaDrzwi, bool rozsuwana) : base(producent, model, cena, wysokosc, szerokosc, glebokosc, material )
        {
            LiczbaDrzwi = liczbaDrzwi;
            Rozsuwana = rozsuwana;
            Kategoria = Kategorie.Szafa;
        }
        public override string ToString()
        {
            return $"Kategoria: {Kategoria}, " + base.ToString() + $", Liczba drzwi: {LiczbaDrzwi}, Rozsuwana: {Rozsuwana}";
        }
    }

    class Lozko : Produkt
    {
        bool materac;
        Kategorie kategoria;
        public Kategorie Kategoria { get => kategoria; set => kategoria = value; }
        public bool Materac { get => materac; set => materac = value; }
        public Lozko()
        {
            Kategoria = Kategorie.Łóżko;
        }

        public Lozko(Producenci producent, string model, int cena, float wysokosc, float szerokosc, float glebokosc, Materialy material,  bool materac) : base(producent, model, cena, wysokosc, szerokosc, glebokosc, material)
        {
            Materac = materac;
            Kategoria = Kategorie.Łóżko;
        }

        public override string ToString()
        {
            return $"Kategoria: {Kategoria}, " + base.ToString() + $", Materac: {Materac}";
        }
    }
    enum Ksztalty { prostokątny, okrągły }
    class Stolik : Produkt
    {
        Ksztalty ksztalt;
        Kategorie kategoria;
        public Kategorie Kategoria { get => kategoria; set => kategoria = value; }
        internal Ksztalty Ksztalt { get => ksztalt; set => ksztalt = value; }

        public Stolik()
        {
            Kategoria = Kategorie.Stolik;
        }

        public Stolik(Producenci producent, string model, int cena, float wysokosc, float szerokosc, float glebokosc, Materialy material, Ksztalty ksztalt) : base(producent, model, cena, wysokosc, szerokosc, glebokosc, material)
        {
            Ksztalt = ksztalt;
            Kategoria = Kategorie.Stolik;
        }
        public override string ToString()
        {
            return $"Kategoria: {Kategoria}, " + base.ToString() + $", Kształt: {Ksztalt}";
        }
    }

    //class Krzeslo : Produkt
    //{
    //    int liczbaNog;
    //    Ksztalty ksztalt;
    //    Kategorie kategoria;
    //    public Kategorie Kategoria { get => kategoria; set => kategoria = value; }

    //    internal Ksztalty Ksztalt { get => ksztalt; set => ksztalt = value; }
    //    public int LiczbaNog { get => liczbaNog; set => liczbaNog = value; }

    //    public Krzeslo()
    //    {
    //        Kategoria = Kategorie.Krzesło;
    //    }

    //    public Krzeslo(Producenci producent, string model, int cena, float wysokosc, float szerokosc, float glebokosc, Materialy material, int dostepna_liczba, int liczbaNog, Ksztalty ksztalt) : base(producent, model, cena, wysokosc, szerokosc, glebokosc, material, dostepna_liczba)
    //    {
    //        LiczbaNog = liczbaNog;
    //        Ksztalt = ksztalt;
    //        Kategoria = Kategorie.Krzesło;
    //    }
    //    public override string ToString()
    //    {
    //        return $"Kategoria: {Kategoria}, " + base.ToString() + $", Liczba nóg: {LiczbaNog}, Kształt: {Ksztalt}";
    //    }
    //}

    //class Komoda : Produkt
    //{
    //    int liczbaSzuflad;
    //    Kategorie kategoria;
    //    public Kategorie Kategoria { get => kategoria; set => kategoria = value; }
    //    public int LiczbaSzuflad { get => liczbaSzuflad; set => liczbaSzuflad = value; }
    //    public Komoda()
    //    {
    //        Kategoria = Kategorie.Komoda;
    //    }

    //    public Komoda(Producenci producent, string model, int cena, float wysokosc, float szerokosc, float glebokosc, Materialy material, int dostepna_liczba, int liczbaSzuflad) : base(producent, model, cena, wysokosc, szerokosc, glebokosc, material, dostepna_liczba)
    //    {
    //        this.LiczbaSzuflad = liczbaSzuflad;
    //        Kategoria = Kategorie.Komoda;
    //    }

    //    public override string ToString()
    //    {
    //        return $"Kategoria: {Kategoria}, " + base.ToString() + $", Liczba szuflad: {LiczbaSzuflad}";
    //    }


    //}
    public enum TypKanapy { Rogowa, Standardowa }

    class Kanapa : Produkt
    {
        bool rozkladana;
        TypKanapy typKanapy;
        Kategorie kategoria;
        public Kategorie Kategoria { get => kategoria; set => kategoria = value; }
        public bool Rozkladana { get => rozkladana; set => rozkladana = value; }
        public TypKanapy TypKanapy { get => typKanapy; set => typKanapy = value; }
        public Kanapa()
        {
            Kategoria = Kategorie.Kanapa;
        }

        public Kanapa(Producenci producent, string model, int cena, float wysokosc, float szerokosc, float glebokosc, Materialy material, bool rozkladana, TypKanapy typKanapy) : base(producent, model, cena, wysokosc, szerokosc, glebokosc, material)
        {
            this.Rozkladana = rozkladana;
            this.TypKanapy = typKanapy;
            Kategoria = Kategorie.Kanapa;
        }

        public override string ToString()
        {
            return $"Kategoria: {Kategoria}, " + base.ToString() + $", Typ: {TypKanapy}, Rozkładana: {Rozkladana}";
        }

    }

    //class Biurko : Produkt
    //{
    //    int liczbaSzafek;
    //    Kategorie kategoria;
    //    public Kategorie Kategoria { get => kategoria; set => kategoria = value; }
    //    public int LiczbaSzafek { get => liczbaSzafek; set => liczbaSzafek = value; }

    //    public Biurko()
    //    {
    //        Kategoria = Kategorie.Biurko;
    //    }
    //    public Biurko(Producenci producent, string model, int cena, float wysokosc, float szerokosc, float glebokosc, Materialy material, int dostepna_liczba, int liczbaSzafek) : base(producent, model, cena, wysokosc, szerokosc, glebokosc, material, dostepna_liczba)
    //    {
    //        this.LiczbaSzafek = liczbaSzafek;
    //        Kategoria = Kategorie.Biurko;
    //    }

    //    public override string ToString()
    //    {
    //        return $"Kategoria: {Kategoria}, " + base.ToString() + $", Liczba szafek: {LiczbaSzafek}";
    //    }

    //}

    //class Fotel : Produkt
    //{
    //    bool obrotowy;
    //    Kategorie kategoria;
    //    public Kategorie Kategoria { get => kategoria; set => kategoria = value; }
    //    public bool Obrotowy { get => obrotowy; set => obrotowy = value; }

    //    public Fotel()
    //    {
    //        Kategoria = Kategorie.Fotel;
    //    }

    //    public Fotel(Producenci producent, string model, int cena, float wysokosc, float szerokosc, float glebokosc, Materialy material, int dostepna_liczba, bool obrotowy) : base(producent, model, cena, wysokosc, szerokosc, glebokosc, material, dostepna_liczba)
    //    {
    //        this.Obrotowy = obrotowy;
    //        Kategoria = Kategorie.Fotel;
    //    }

    //    public override string ToString()
    //    {
    //        return $"Kategoria: {Kategoria}, " + base.ToString() + $", Obrotowy: {Obrotowy}";
    //    }

}

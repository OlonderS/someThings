﻿using System;

namespace WpfApp2
{
    static class Pracownik
    {
        
        public static void ObsluzKlienta()  //to bym wywalił i zrobił od strony klienta
        {
            Sklep.kasa = 0;
          
        }

        public  static void DodajProdukt(Produkt produkt)
        {
            if (Sklep.ListaProduktow.Find(x => x.Producent == produkt.Producent && x.Model==produkt.Model) is object)
                throw new Exception("W sklepie już jest taki produkt");
            //jeśli dostepna liczba = 0 to exception
            Sklep.ListaProduktow.Add(produkt);
        }

        public static  void ZwiekszStan(Produkt produkt, int liczba)
        {
        //    if (Sklep.ListaProduktow.Find(x => x.ProduktID == produkt.ProduktID) is object)
        //        produkt.Dostepna_liczba += liczba;
        //    else
        //        throw new Exception("W sklepie nie ma takiego produktu");
        }
    }
}

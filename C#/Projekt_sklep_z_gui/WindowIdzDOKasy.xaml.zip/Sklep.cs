﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp2
{
    static class Sklep   // ogolem nie wiem jak dziala to static i czy to ma sens ale sklep raczej jako tako powinien byc static, tak samo kolejka?
    {
        public static float kasa;
        public static string nazwa;
       
        static List<Produkt> listaProduktow;
        internal static List<Produkt> ListaProduktow { get => listaProduktow; set => listaProduktow = value; }
        static Sklep()
        {
            nazwa = "bodzio";
         
            ListaProduktow = new List<Produkt>();
        }

        public static void UsunZeSklepu(Produkt p)
        {
            listaProduktow.Remove(p);
        }
    }
}
